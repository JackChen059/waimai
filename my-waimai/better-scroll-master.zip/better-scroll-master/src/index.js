import {BScroll} from './bscroll/bscroll';

BScroll.Version = '0.4.0';

export default BScroll;